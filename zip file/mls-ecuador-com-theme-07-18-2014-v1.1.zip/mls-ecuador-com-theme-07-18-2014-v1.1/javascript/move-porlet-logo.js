$(document).ready(function() {
    $(".agency_logo").insertAfter(".contact_details");
});
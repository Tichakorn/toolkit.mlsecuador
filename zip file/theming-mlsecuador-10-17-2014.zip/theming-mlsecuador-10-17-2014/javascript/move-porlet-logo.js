$(document).ready(function() {
    $(".agency_logo").insertAfter(".contact_details");
    $("body #portal-column-content" ).insertAfter("body #portal-column-one" );
});
